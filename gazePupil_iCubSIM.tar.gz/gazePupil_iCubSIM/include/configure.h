// -*- mode:C++; tab-width:4; c-basic-offset:4; indent-tabs-mode:nil -*-
//
#ifndef CONFIGURE_H
#define CONFIGURE_H

#include <yarp/os/all.h>
#include <yarp/dev/all.h>
#include <yarp/sig/all.h>

#include <yarp/sig/Vector.h>

#include "init.h"       

#endif
